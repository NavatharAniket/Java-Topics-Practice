class Practice{
	public static void main(String[] args)
	{
		int[] arr={};
	}
}