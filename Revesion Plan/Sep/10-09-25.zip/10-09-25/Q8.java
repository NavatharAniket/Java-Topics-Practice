class Q8
{
	public static void main(String[] args)
	{
		
	}
}