class MaxSumAtMostK {
    public static int findMaxSum(int[] arr, int k) {
        int maxSum = 0, sum = 0, start = 0;
        for (int end = 0; end < arr.length; end++) {
            sum += arr[end];
            if (end - start + 1 > k) {
                sum -= arr[start++];
            }
            maxSum = Math.max(maxSum, sum);
        }
        return maxSum;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        System.out.println(findMaxSum(arr, 3)); // 12
    }
}
