class Q4
{
	public static void main(String[] args)
	{
		int[] arr={1, 2, 1, 3, 4, 2, 3};
		int k=4;
		
		
		
	}
}